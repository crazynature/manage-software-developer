/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phaseb;

/**
 *
 * @author cjrjh
 */
public class Assignment {
    //current assignment's ID
    private int assignmentId;
    //the submissions under this assignment
    private Submission submissionsSubmission[];
    //the ID of the teacher who create this assignment
    private int teacherId;
    
     /**
     *Parameters: 
     *Returns: a Submission array
     *Interpretation:get all Submissions under this assignment
     *             
     */
    public Submission[] getSubmission(){
        return null;
    }
}
