package filesystem;

class DuVisitor implements Visitor {
  DuVisitor(){
    _nrFiles = 0; _nrDirectories = 0;
    _nrLinks = 0; _totalSize = 0;
  }
  public void visit(File f){
    _nrFiles++;
    _totalSize += f.size();
  }
  public void visit(Directory d){
    _nrDirectories++;
  }
  public void visit(Link l){ // does not follow links
    _nrLinks++;
  }
  public void report(){
    System.out.println("files:       " + _nrFiles);
    System.out.println("directories: " + _nrDirectories);
    System.out.println("links:       " + _nrLinks);
    System.out.println("total size:  " + _totalSize);
  }
  int _totalSize; int _nrFiles; int _nrLinks; int _nrDirectories;
}

