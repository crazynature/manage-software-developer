/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phaseb;

/**
 *
 * @author cjrjh
 */
public class ComparisonRestult {

    //the textual comparison result
    public double textualSimilarity;
    //the ast comparison result
    public double astSimilarity;
    //the total result
    public double totalSimilarity;

    /**
     *Parameters:null
     *Returns: a number 
     *Interpretation: return the the textual comparison result
     *                  
     */    
    public double getTextualSimilarity() {
        return 0;
    }
    /**
     *Parameters:null
     *Returns: a number 
     *Interpretation: return the the ast comparison result
     *                  
     */
    public double getAstSimilarity() {
        return 0;
    }
    /**
     *Parameters:null
     *Returns: a number 
     *Interpretation: return the the total comparison result
     *                  
     */
    public double getTotalResult() {
        return 0;
    }
}
