package filesystem;

interface Observer {
  public void update();
}
