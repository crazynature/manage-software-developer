/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gourpproject;

/**
 *
 * @author cjrjh
 */
abstract class Assignment {

    private File files[];
    private int assignmentId;
    private int studentId;
    private int teachId;

    public abstract void submit();

    public abstract void clear();

    public abstract File getFile(String fileName);

    public abstract Assignment getAssignment(int assignmentId);

    public File[] getFiles() {
        return files;
    }

    public void setFiles(File[] files) {
        this.files = files;
    }

    public int getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId(int assignmentId) {
        this.assignmentId = assignmentId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getTeachId() {
        return teachId;
    }

    public void setTeachId(int teachId) {
        this.teachId = teachId;
    }

}
