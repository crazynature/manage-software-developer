package com.github.javaparser.ast.validator;

/**
 * This validator validates according to Java 1.3 syntax rules.
 */
public class Java1_3Validator extends Java1_2Validator {
    public Java1_3Validator() {
        super();
    }
}
