package filesystem;

import java.util.Vector;

abstract class Node {
  Node(String name, Directory parent) {
    _name = name; _parent = parent;
    if (_parent != null) {
      parent.add(this);
    }
  }
  public String getAbsoluteName() {
    if (_parent != null) {
      return _parent.getAbsoluteName() + _name;
    }
    return _name;
  }
  public String toString() {
    return getAbsoluteName();
  }
  public abstract Vector<String> find(String s);

  protected String _name;
  protected Directory _parent;
}
