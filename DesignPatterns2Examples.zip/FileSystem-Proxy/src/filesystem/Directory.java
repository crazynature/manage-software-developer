package filesystem;

import java.util.Vector;

class Directory extends Node {
  Directory(String n){ this(n, null); } 
  Directory(String n, Directory p){ 
    super(n,p);
    _children = new Vector<Node>(); 
  }
  public String getAbsoluteName(){
    return super.getAbsoluteName() + "/";
  }  
  public void add(Node n){
    _children.addElement(n); 
  }
  public Vector<String> find(String s){
    Vector<String> result = new Vector<String>();
    if (_name.indexOf(s) != -1){
      result.add(getAbsoluteName());
    }
    for (Node child : _children){
      result.addAll(child.find(s));
    }
    return result;
  }
  private Vector<Node> _children;
}
