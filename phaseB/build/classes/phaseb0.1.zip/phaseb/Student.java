/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phaseb;

/**
 *
 * @author cjrjh
 */
public class Student extends User{

    

    /**
     *Parameters: null
     *Returns: null
     *Interpretation:Choose a folder to upload
     *                  
     */ 
    public void chooseFoler(){
        
    }
    
     /**
     *Parameters: null
     *Returns: null
     *Interpretation:Choose files to upload
     *                  
     */
    public void chooseFile(){
        
    }

    @Override
    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void register() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void login() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public Boolean findUser(String username, String password) {
        throw new UnsupportedOperationException("Not supported yet.");
    }


    
    
    
}
