package filesystem;

import java.util.List;
import java.util.ArrayList;

class Directory extends Node {
  Directory(String n){ this(n, null); } 
  Directory(String n, Directory p){ 
    super(n,p);
    _children = new ArrayList<Node>(); 
  }
  public String getAbsoluteName(){
    return super.getAbsoluteName() + "/";
  }  
  public void add(Node n){
    _children.add(n); 
  }
  public List<String> find(String s){
    List<String> result = new ArrayList<String>();
    if (_name.indexOf(s) != -1){
      result.add(getAbsoluteName());
    }
    for (Node child : _children){
      result.addAll(child.find(s));
    }
    return result;
  }
  
  public Iterator<Node> iterator() {
    return new DirectoryIterator(this);
  }

  // use a private inner class because:
  // - it is not visible outside the class
  // - its methods have access to Directory’s
  // private field _children
  private class DirectoryIterator 
    implements Iterator<Node> {
    private List<Node> _files;
    private int _fileCnt;

    DirectoryIterator(Directory d) {
      _files = d._children; _fileCnt = 0;
    }

    public void first() { _fileCnt = 0; }
    public void next() { _fileCnt++; }
    public boolean isDone() {
      return _fileCnt == _files.size();
    }
    public Node current() {
      return _files.get(_fileCnt);
    }
  }  
  
  private List<Node> _children;
}
