package bridge;

interface StackImpl<T> {
  public void push(T t);
  public T pop();
}
