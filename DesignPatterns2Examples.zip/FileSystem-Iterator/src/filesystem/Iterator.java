package filesystem;

interface Iterator<T> {
  void first();     // set to first
  void next();      // advance
  boolean isDone(); // is done
  T current(); // get current
}
