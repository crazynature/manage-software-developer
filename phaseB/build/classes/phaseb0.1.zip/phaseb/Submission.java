/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phaseb;

/**
 *
 * @author cjrjh
 */
class Submission {
    //current Submission ID
    private int id;
    //the files under this Submission
    private File files[];
    //the id of the student who submit this submission
    private int studentId;
    
     /**
     *Parameters: a integer for submission id
     *Returns: this submission
     *Interpretation:get the data of current submission
     *                  
     */
    public Submission getSubmission(int submissionId){
        return null;
    }
    
     /**
     *Parameters: a id
     *Returns: null
     *Interpretation:remove the submission 
     *                  
     */
    public void remove(){
        
    }
     /**
     *Parameters: a File array
     *Returns: null
     *Interpretation:upload the files to current submission
     *                  
     */
    public void submit(File[] homework){
        
    }
}
