package filesystem;

public class Main { 
  public static void main(String[] args){
    Directory root = new Directory("");
    new File("core", root);
    Directory usr = new Directory("usr", root);
    new File("adm", usr);
    Directory foo = new Directory("foo", usr);
    new File("bar1", foo);
    new File("xbar2", foo);
    new File("yybarzz3", foo);
    Link link = new Link("link", usr, root);
    new Link("link2", link, root);
    System.out.println(root.find("bar"));
  }
}

