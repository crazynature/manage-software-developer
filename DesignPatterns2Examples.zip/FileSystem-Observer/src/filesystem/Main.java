package filesystem;

public class Main { 
  public static void main(String[] args){
    Directory root = new Directory("");
    File core = new File("core", root);
    
    // create observer for file core
    FileObserver obs = new FileObserver(core);
    core.write("hello");
    core.write("world"); 
  }
}