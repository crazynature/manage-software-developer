package filesystem;

import java.util.List;
import java.util.ArrayList;

class Directory extends Node {
  Directory(String n){ this(n, null); } 
  Directory(String n, Directory p){ 
    super(n,p);
    _children = new ArrayList<Node>(); 
  }
  public String getAbsoluteName(){
    return super.getAbsoluteName() + "/";
  }  
  public void add(Node n){
    _children.add(n); 
  }
  private List<Node> _children;
}
