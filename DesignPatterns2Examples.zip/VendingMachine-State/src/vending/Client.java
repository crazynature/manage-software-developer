package vending;

public class Client {
  public static void main(String[] args) {
    VendingMachine v = new VendingMachine();
    v.addNickel();
    v.addDime();
    v.addNickel();
    v.addQuarter();
  }
}
