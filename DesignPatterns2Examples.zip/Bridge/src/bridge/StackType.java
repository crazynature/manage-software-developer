package bridge;

public enum StackType { 
   Array, 
   LinkedList 
}
