package filesystem;

import java.util.Vector;

class Link extends Node { 
  Link(String n, Node w, Directory p){
    super(n,p); _realNode = w;  
  }
  public String getAbsoluteName(){
    return super.getAbsoluteName() + "@";
  }   
  public Vector<String> find(String s){
    Vector<String> result = new Vector<String>();
    if (_name.indexOf(s) != -1){
      result.add(getAbsoluteName());
    }  
    Vector<String> resultsViaLink = _realNode.find(s);
    int n = _realNode.getAbsoluteName().length();
    for (String r : resultsViaLink){
      String name = super.getAbsoluteName() + "/" + r.substring(n);
      result.add(name);
    }
    return result;
  }
  public void accept(Visitor v){
    v.visit(this);
  } 
  
  private Node _realNode;
}
