package filesystem;

import java.util.Vector;

class File extends Node { 
  File(String n, Directory p, String c){ 
    super(n,p); 
    _content = c;
  }
  public Vector<String> find(String s){
    Vector<String> result = new Vector<String>();
    if (_name.indexOf(s) != -1){
      result.add(this.getAbsoluteName());
    }  
    return result;
  }
  public int size(){
    return _content.length();
  }
  public void accept(Visitor v){
    v.visit(this);
  } 
  
  private String _content;
}
