/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gourpproject;

/**
 *
 * @author cjrjh
 */
abstract class File {

    private String fileName;
    private int fileSize;
    private String dataSubmitted[];
    private int assignmentId;
    private String text[];

    public abstract void readData();

    public abstract void uploadFile();

    public abstract void parseData();

    public abstract File getFile(int assignmentId);
}
