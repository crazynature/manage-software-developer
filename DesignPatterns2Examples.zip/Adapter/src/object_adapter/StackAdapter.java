package object_adapter;

import java.util.Vector;

class StackAdapter<T> implements Stack<T> {
  StackAdapter() {
    _adaptee = new Vector<T>();
  }
  public void push(T t) {
    _adaptee.insertElementAt(t, _adaptee.size());
  }
  public T pop() {
    T t = _adaptee.elementAt(_adaptee.size() - 1);
    _adaptee.removeElementAt(_adaptee.size() - 1);
    return t;
  }
  public int size() {
    return _adaptee.size();
  }
  private Vector<T> _adaptee;
}
