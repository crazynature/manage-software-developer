/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phaseb;

/**
 *
 * @author cjrjh
 */
public class TextualComparison implements Comparison{
    //the result for current Comparison 
    private double result;
    
    @Override
    public void compare(Submission one, Submission two) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public double reportResult() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
