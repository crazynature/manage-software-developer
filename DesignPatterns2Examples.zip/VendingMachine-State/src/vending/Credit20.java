package vending;

class Credit20 implements VendingMachineState {
  private Credit20(){ }
  private static Credit20 _theInstance;
  static Credit20 instance(){ 
    if (_theInstance == null){ 
      _theInstance = new Credit20();
    }
    return _theInstance;
  }
  public void addNickel(VendingMachine v) {
    v.dispenseProduct();
    v.changeState(Credit0.instance(v));     }
  public void addDime(VendingMachine v) {
    v.dispenseProduct(); v.refund(5);
    v.changeState(Credit0.instance(v)); }
  public void addQuarter(VendingMachine v) {
    v.dispenseProduct(); v.refund(20);
    v.changeState(Credit0.instance(v));   }
  public int getBalance(){ return 20; }
}
