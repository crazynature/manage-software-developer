package vending;

class Credit15 implements VendingMachineState {
  private Credit15(){ }
  private static Credit15 _theInstance;
  static Credit15 instance(){ 
    if (_theInstance == null){ 
      _theInstance = new Credit15();
    }
    return _theInstance;
  }
  public void addNickel(VendingMachine v) {
    v.changeState(Credit20.instance());     }
  public void addDime(VendingMachine v) {
    v.dispenseProduct();
    v.changeState(Credit0.instance(v)); }
  public void addQuarter(VendingMachine v) {
    v.dispenseProduct(); v.refund(15);
    v.changeState(Credit0.instance(v));   }
  public int getBalance(){ return 15; }
}
