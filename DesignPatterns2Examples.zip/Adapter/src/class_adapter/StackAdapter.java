package class_adapter;

import java.util.Vector;

@SuppressWarnings("serial")
class StackAdapter<T> extends Vector<T> implements Stack<T> {
  StackAdapter(){ 
    super(); 
  } 
  public void push(T t){ 
    insertElementAt(t, size()); 
  }
  public T pop(){ 
    T t = elementAt(size()-1);
    removeElementAt(size()-1);
    return t;
  }
  
  // inherit size() method from Vector
}
