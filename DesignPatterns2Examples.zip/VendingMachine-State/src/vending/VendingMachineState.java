package vending;

interface VendingMachineState {
  void addNickel(VendingMachine v);
  void addDime(VendingMachine v);
  void addQuarter(VendingMachine v);
  int getBalance();
}
