package vending;

class VendingMachine {
  private int _balance;
  public VendingMachine() {
    _balance = 0; welcome();
  }
  void welcome() {
    System.out.println("Welcome. Please enter $0.25 to buy product.");
  }
  void dispenseProduct() {
    System.out.println("dispensing product...");
  }
  void displayBalance() {
    System.out.println("balance is now: " + _balance);
  }
  void refund(int i) {
    System.out.println("refunding: " + i);
  }

  public void addNickel() {
    switch (_balance) {
    case 0 : { _balance = 5;
    displayBalance();
    break;  }
    case 5 : { _balance = 10;
    displayBalance();
    break; }
    case 10 : { _balance = 15;
    displayBalance();
    break; }
    case 15 : { _balance = 20;
    displayBalance();
    break; }
    case 20 : { dispenseProduct();
    _balance = 0; welcome();
    break; }
    }
  }

  public void addDime() {
    switch (_balance) {
    case 0 : { _balance = 10;
    displayBalance();
    break; }
    case 5 : { _balance = 15;
    displayBalance();
    break; }
    case 10 : { _balance = 20;
    displayBalance();
    break; }
    case 15 : { dispenseProduct();
    _balance = 0; welcome();
    break; }
    case 20 : { dispenseProduct();
    refund(5); _balance = 0; welcome();
    break; }
    }
  }
  
  public void addQuarter() {
    switch (_balance) {
    case 0 : { dispenseProduct();
    _balance = 0; welcome();
    break; }
    case 5 : { dispenseProduct();
    refund(5); _balance = 0; welcome();
    break; }
    case 10 : { dispenseProduct();
    refund(10); _balance = 0; welcome();
    break; }
    case 15 : { dispenseProduct();
    refund(15); _balance = 0; welcome();
    break; }
    case 20 : { dispenseProduct();
    refund(20); _balance = 0; welcome();
    break; }
    }
  }
}
