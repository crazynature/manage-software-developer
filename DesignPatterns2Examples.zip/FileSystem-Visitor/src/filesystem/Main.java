package filesystem;

public class Main {   
  public static void main(String[] args){
    Directory root = new Directory("");
    new File("core", root, "hello");
    Directory usr = new Directory("usr", root);
    new File("adm", usr, "there");
    new Directory("foo", usr);
    new File("bar1", usr, "abcdef");
    new File("xbar2", usr, "abcdef");
    new File("yybarzz3", usr, "abcdef");
    Link link = new Link("link", usr, root);
    new Link("link2", link, root);
  
    DuVisitor visitor = new DuVisitor();
    root.accept(visitor);
    visitor.report();
  }
}