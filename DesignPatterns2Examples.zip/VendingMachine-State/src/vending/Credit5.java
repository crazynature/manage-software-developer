package vending;

class Credit5 implements VendingMachineState {
  private Credit5(){ }
  private static Credit5 _theInstance;
  static Credit5 instance(){ 
    if (_theInstance == null){ 
      _theInstance = new Credit5();
    }
    return _theInstance;
  }
  public void addNickel(VendingMachine v) {
    v.changeState(Credit10.instance());     }
  public void addDime(VendingMachine v) {
    v.changeState(Credit15.instance());   }
  public void addQuarter(VendingMachine v) {
    v.dispenseProduct(); v.refund(5);
    v.changeState(Credit0.instance(v));   }
  public int getBalance(){ return 5; }
}
