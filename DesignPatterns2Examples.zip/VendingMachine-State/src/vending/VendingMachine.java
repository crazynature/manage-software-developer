package vending;

public class VendingMachine {
  public VendingMachine() {
    _state = Credit0.instance(this);
  }
  
  void welcome() {
    System.out.println("Welcome. Please enter $0.25 to buy product.");
  }
  void dispenseProduct() {
    System.out.println("dispensing product...");
  }
  void displayBalance() {
    System.out.println("balance is now: " +_state.getBalance());
  }
  void refund(int i) {
    System.out.println("refunding: " + i);
  }
  
  // methods welcome(), displayBalance() etc. as before
  
  void changeState(VendingMachineState s) {
    _state = s; displayBalance();
  }
  public void addNickel() { _state.addNickel(this); }
  public void addDime() { _state.addDime(this); }
  public void addQuarter() { _state.addQuarter(this); }
  private VendingMachineState _state;
}
