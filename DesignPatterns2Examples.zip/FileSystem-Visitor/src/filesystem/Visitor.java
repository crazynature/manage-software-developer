package filesystem;

interface Visitor {
  void visit(File f);
  void visit(Directory d);
  void visit(Link l);
}
